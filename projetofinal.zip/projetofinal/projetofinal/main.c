//
//  main.c
//  projetofinal
//
//  Created by Faculdade on 24/12/2019.
//  Copyright © 2019 Patricia. All rights reserved.
//

#include <stdio.h>
#include "fase2.h"

int main(int argc,const char *argv[]) {
   // main_fase1(argc,argv);
    //main_bts();
    clientSudoku();
    return 0;
}
